package test_000a;

import static org.junit.Assert.*;

import org.junit.Test;

public class FindMinTest {

	@Test
	public void testFindMax() {
		int [] array = {4,9,7,19,94,5,2};
		assertEquals(2,new FindMin().findMin(array));
}
	}

