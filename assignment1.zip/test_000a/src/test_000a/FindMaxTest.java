package test_000a;

import static org.junit.Assert.*;

import org.junit.Test;

public class FindMaxTest {

	@Test
	public void testFindMax() {
	int [] array = {2,4,9,7,19,94,5};
		assertEquals(94,new FindMax().findMax(array));
	}

}
