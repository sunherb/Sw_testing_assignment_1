package test_000a;

import static org.junit.Assert.*;

import org.junit.Test;

public class FactorialTest {

	@Test
	public void testFactorial() {
	try {
		assertEquals(120,new Factorial().factorial(5));
	    assertEquals(-1,new Factorial().factorial(-5));
	}
	catch(Exception e)
	{
		
	}
	}

	
}
